<?php
// Heading
$_['heading_title']         = 'QartPay';

// Text
$_['text_extension']        = 'Extensions';
$_['text_success']          = 'Success: You have modified QartPay account details!';
$_['text_edit']             = 'Edit QartPay';
$_['text_Qartpay']        = '<img src="view/image/payment/Qartpay.png" alt="QartPay" title="QartPay" style="border: 1px solid #EEEEEE;" />';

// Entry
$_['entry_pay_id']          = 'QartPay Pay ID';
$_['entry_salt']            = 'Salt';
$_['entry_test']            = 'Test Mode';
$_['entry_total']           = 'Total';
$_['entry_order_status']    = 'Order Status';
$_['entry_geo_zone']        = 'Geo Zone';
$_['entry_status']          = 'Status';
$_['entry_sort_order']      = 'Sort Order';

// Help
$_['help_salt']             = 'QartPay Salt';
$_['help_total']            = 'The checkout total the order must reach before this payment method becomes active.';

// Error
$_['error_permission']      = 'Warning: You do not have permission to modify payment QartPay!';
$_['error_pay_id']          = 'QartPay Pay ID required!';
$_['error_salt']            = 'Salt required!';
